

$(document).ready(function() {
var my_val = 0;
$(".toggle_menu").click(function(){
	my_val = my_val+1;

	if (my_val%2 != 0) 
	{
		$(".nav_slide").animate({left:0},600);
		$(".overlay").addClass('nav-fixed');
		$("body").addClass('bodyslide');
		$(".toggle_menu").addClass('cross');
		
	}
	else
	{
		$(".nav_slide").animate({left: "-100%"},1000);
		$(".overlay").removeClass('nav-fixed');
		$("body").removeClass('bodyslide');
		$(".toggle_menu").animate({right:10},600);
		$(".toggle_menu").removeClass('cross');
	}
});

});









